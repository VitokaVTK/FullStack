namespace CineHub; public partial class App : System.Windows.Application { }
