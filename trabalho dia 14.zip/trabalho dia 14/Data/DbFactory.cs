using System.IO;
using Microsoft.EntityFrameworkCore;
namespace CineHub.Data;
public static class DbFactory { public static CineDbContext Create() { var path=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"cinehub.db"); return new(new DbContextOptionsBuilder<CineDbContext>().UseSqlite($"Data Source={path}").Options); } }
