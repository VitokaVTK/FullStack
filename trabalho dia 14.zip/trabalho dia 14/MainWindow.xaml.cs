using System.Windows; using System.Windows.Controls; using System.Windows.Media; using CineHub.Data; using CineHub.Models; using CineHub.Services; using Microsoft.EntityFrameworkCore;
namespace CineHub;
public partial class MainWindow : Window {
 readonly CineDbContext db=DbFactory.Create(); CatalogService service=null!; DataGrid? grid; TextBox? a,b,c,d; ComboBox? genreBox,directorBox; Movie? selectedMovie;
 Brush ink=new SolidColorBrush(Color.FromRgb(23,32,51)), muted=new SolidColorBrush(Color.FromRgb(119,129,151)), white=Brushes.White, accent=new SolidColorBrush(Color.FromRgb(108,92,231));
 public MainWindow(){InitializeComponent();Loaded+=async(_,_)=>{try{await InitializeDb();service=new(db);await Show("dashboard");}catch(Exception ex){Error(ex);}};}
 async Task InitializeDb(){await db.Database.EnsureCreatedAsync();if(!await db.Genres.AnyAsync()){var action=new Genre{Name="Ação",Description="Aventura e adrenalina"};var drama=new Genre{Name="Drama",Description="Histórias humanas"};var sci=new Genre{Name="Ficção científica",Description="Futuros e mundos imaginados"};var comedy=new Genre{Name="Comédia",Description="Humor para todos"};db.Genres.AddRange(action,drama,sci,comedy);var nolan=new Director{Name="Christopher Nolan",Country="Reino Unido",BirthYear=1970};var greta=new Director{Name="Greta Gerwig",Country="Estados Unidos",BirthYear=1983};db.Directors.AddRange(nolan,greta);db.Movies.AddRange(new Movie{Title="A Origem",ReleaseYear=2010,Genre= sci,Director=nolan,Rating=8.8,Synopsis="Um ladrão invade sonhos para roubar segredos."},new Movie{Title="Interestelar",ReleaseYear=2014,Genre=sci,Director=nolan,Rating=8.7,Synopsis="Uma viagem para além da galáxia em busca de um novo lar."},new Movie{Title="Adoráveis Mulheres",ReleaseYear=2019,Genre=drama,Director=greta,Rating=7.8,Synopsis="Quatro irmãs crescem e descobrem seu próprio caminho."},new Movie{Title="Barbie",ReleaseYear=2023,Genre=comedy,Director=greta,Rating=7.0,Synopsis="Uma aventura cor-de-rosa sobre identidade e possibilidades."});await db.SaveChangesAsync();}}
 async void Navigate_Click(object sender,RoutedEventArgs e){try{await Show((string)((Button)sender).Tag);}catch(Exception ex){Error(ex);}}
 async Task Show(string page){MainContent.Children.Clear();grid=null;selectedMovie=null;PageTitle.Text=page switch{"dashboard"=>"Visão geral","movies"=>"Filmes","genres"=>"Gêneros","directors"=>"Diretores",_=>"Pesquisar filmes"};if(page=="dashboard")await Dashboard();else if(page=="movies")await MoviesPage();else if(page=="genres")await CatalogPage(false);else if(page=="directors")await CatalogPage(true);else await SearchPage();}
 async Task Dashboard(){var welcome=Card(new StackPanel{Children={Txt("Bem-vindo ao CineHub",26,true,ink),Txt("Seu catálogo de cinema em um só lugar. Gerencie filmes, gêneros e diretores.",14,false,muted)}});MainContent.Children.Add(welcome);var wrap=new WrapPanel{Margin=new Thickness(0,22,0,0)};MainContent.Children.Add(wrap);var count=await service.MovieCount();var genreCount=await service.GenreCount();var directorCount=await service.DirectorCount();var avg=await service.AverageRating();AddDashCard(wrap,"🎞","Filmes",count.ToString(),"Gerenciar catálogo completo","movies");AddDashCard(wrap,"◈","Gêneros",genreCount.ToString(),"Organizar categorias","genres");AddDashCard(wrap,"◉","Diretores",directorCount.ToString(),"Explorar cineastas","directors");AddDashCard(wrap,"★","Nota média",avg.ToString("0.0"),"Encontrar um título","search");var recent=await service.Movies();MainContent.Children.Add(Txt("Adicionados ao catálogo",18,true,ink,new Thickness(2,28,0,12)));var panel=Card(new StackPanel());foreach(var m in recent.Take(4))((StackPanel)panel.Child).Children.Add(Txt($"{m.Title}     ·     {m.ReleaseYear}     ·     {m.Genre?.Name}     ·     ★ {m.Rating:0.0}",14,false,ink,new Thickness(0,8,0,8)));MainContent.Children.Add(panel);}
 void AddDashCard(Panel host,string icon,string title,string value,string note,string target){var body=new StackPanel{Children={Txt(icon+"   "+title,13,true,muted),Txt(value,30,true,ink,new Thickness(0,15,0,5)),Txt(note,12,false,muted)}};var btn=new Button{Content=body,Tag=target,Background=white,Foreground=ink,Padding=new Thickness(20),Margin=new Thickness(0,0,14,12),Width=225,Height=150,HorizontalContentAlignment=HorizontalAlignment.Left,BorderBrush=new SolidColorBrush(Color.FromRgb(231,233,241)),BorderThickness=new Thickness(1)};btn.Click+=Navigate_Click;host.Children.Add(btn);}
 async Task MoviesPage(){var head=new StackPanel{Children={Txt("Biblioteca de filmes",22,true,ink),Txt("Crie, edite, pesquise e remova títulos do seu catálogo.",13,false,muted,new Thickness(0,4,0,18))}};MainContent.Children.Add(head);var form=Card(new StackPanel());MainContent.Children.Add(form);var f=(StackPanel)form.Child;f.Children.Add(Txt("DETALHES DO FILME",11,true,muted,new Thickness(0,0,0,12)));var row=new WrapPanel();f.Children.Add(row);a=Input(row,"Título",250);b=Input(row,"Ano",90);c=Input(row,"Nota (0–10)",110);genreBox=Combo(row,"Gênero",await service.Genres());directorBox=Combo(row,"Diretor",await service.Directors());d=Input(f,"Sinopse",700);var actions=new StackPanel{Orientation=Orientation.Horizontal};f.Children.Add(actions);Act(actions,"Salvar novo",async()=>await SaveMovie(false));Act(actions,"Atualizar selecionado",async()=>await SaveMovie(true));Act(actions,"Excluir selecionado",async()=>await DeleteMovie());Act(actions,"Limpar",()=>{ClearMovie();return Task.CompletedTask;});grid=GridView(new[]{"Id","Título","Ano","Gênero","Diretor","Nota","Sinopse"});grid.SelectionChanged+=(_,_)=>SelectMovie();MainContent.Children.Add(grid);await RefreshMovies();}
 async Task CatalogPage(bool directors)
 {
     var isD = directors;
     MainContent.Children.Add(Txt(isD ? "Diretores" : "Gêneros", 22, true, ink));
     MainContent.Children.Add(Txt(
         isD ? "Cadastre cineastas e consulte os títulos associados."
             : "Mantenha as categorias usadas no catálogo.",
         13, false, muted, new Thickness(0, 4, 0, 18)));

     var form = Card(new StackPanel());
     MainContent.Children.Add(form);
     var fields = (StackPanel)form.Child;
     a = Input(fields, isD ? "Nome do diretor" : "Nome do gênero", 300);
     b = Input(fields, isD ? "País" : "Descrição", 300);
     if (isD)
         c = Input(fields, "Ano de nascimento", 110);

     var actions = new StackPanel { Orientation = Orientation.Horizontal };
     fields.Children.Add(actions);

     Act(actions, isD ? "Adicionar diretor" : "Adicionar gênero", async () =>
     {
         if (string.IsNullOrWhiteSpace(a?.Text))
             throw new InvalidOperationException("Informe o nome.");

         if (isD)
         {
             if (!int.TryParse(c?.Text, out int birthYear))
                 throw new InvalidOperationException("Informe um ano de nascimento válido.");

             await service.AddDirector(new Director
             {
                 Name = a.Text.Trim(),
                 Country = b?.Text.Trim() ?? "",
                 BirthYear = birthYear
             });
         }
         else
         {
             await service.AddGenre(new Genre
             {
                 Name = a.Text.Trim(),
                 Description = b?.Text.Trim() ?? ""
             });
         }

         ClearFields();
         await RefreshCatalog(isD);
     });

     Act(actions, "Atualizar selecionado", async () =>
     {
         if (grid?.SelectedItem is not object[] values)
             throw new InvalidOperationException("Selecione um registro na tabela.");
         if (string.IsNullOrWhiteSpace(a?.Text))
             throw new InvalidOperationException("Informe o nome.");

         var id = Convert.ToInt32(values[0]);
         if (isD)
         {
             if (!int.TryParse(c?.Text, out int birthYear))
                 throw new InvalidOperationException("Informe um ano de nascimento válido.");

             await service.UpdateDirector(new Director
             {
                 Id = id,
                 Name = a.Text.Trim(),
                 Country = b?.Text.Trim() ?? "",
                 BirthYear = birthYear
             });
         }
         else
         {
             await service.UpdateGenre(new Genre
             {
                 Id = id,
                 Name = a.Text.Trim(),
                 Description = b?.Text.Trim() ?? ""
             });
         }

         ClearFields();
         await RefreshCatalog(isD);
     });

     Act(actions, "Excluir selecionado", async () =>
     {
         if (grid?.SelectedItem is not object[] values)
             throw new InvalidOperationException("Selecione um registro na tabela.");

         var id = Convert.ToInt32(values[0]);
         if (isD)
             await service.DeleteDirector(id);
         else
             await service.DeleteGenre(id);

         ClearFields();
         await RefreshCatalog(isD);
     });

     grid = GridView(isD
         ? new[] { "Id", "Nome", "País", "Ano", "Filmes" }
         : new[] { "Id", "Nome", "Descrição", "Filmes" });

     grid.SelectionChanged += (_, _) =>
     {
         if (grid.SelectedItem is not object[] values)
             return;

         a!.Text = values[1]?.ToString() ?? "";
         b!.Text = values[2]?.ToString() ?? "";
         if (isD && c is not null)
             c.Text = values[3]?.ToString() ?? "";
     };

     MainContent.Children.Add(grid);
     await RefreshCatalog(isD);
 }
 async Task SearchPage(){MainContent.Children.Add(Txt("Encontre seu próximo filme",22,true,ink));MainContent.Children.Add(Txt("Pesquise por título, gênero ou diretor. A consulta usa LINQ parametrizado.",13,false,muted,new Thickness(0,4,0,18)));var row=new StackPanel{Orientation=Orientation.Horizontal};MainContent.Children.Add(row);a=Input(row,"Digite título, gênero ou diretor",360);Act(row,"Pesquisar",async()=>await RunSearch());Act(row,"Limpar",async()=>{a!.Text="";await RunSearch();});grid=GridView(new[]{"Id","Título","Ano","Gênero","Diretor","Nota","Sinopse"});MainContent.Children.Add(grid);await RunSearch();}
 async Task RunSearch(){if(grid is null)return;try{var list=string.IsNullOrWhiteSpace(a?.Text)?await service.Movies():await service.Search(a!.Text.Trim());grid.ItemsSource=list.Select(x=>new object[]{x.Id,x.Title,x.ReleaseYear,x.Genre?.Name??"",x.Director?.Name??"",x.Rating,x.Synopsis}).ToList();}catch(Exception ex){Error(ex);}}
 async Task RefreshMovies(){if(grid is null)return;try{var list=await service.Movies();grid.ItemsSource=list.Select(x=>new object[]{x.Id,x.Title,x.ReleaseYear,x.Genre?.Name??"",x.Director?.Name??"",x.Rating,x.Synopsis}).ToList();}catch(Exception ex){Error(ex);}}
 async Task RefreshCatalog(bool director){if(grid is null)return;try{if(director){var xs=await service.Directors();grid.ItemsSource=xs.Select(x=>new object[]{x.Id,x.Name,x.Country,x.BirthYear,x.Movies.Count}).ToList();}else{var xs=await service.Genres();grid.ItemsSource=xs.Select(x=>new object[]{x.Id,x.Name,x.Description,x.Movies.Count}).ToList();}}catch(Exception ex){Error(ex);}}
 async Task SaveMovie(bool update)
 {
     if (string.IsNullOrWhiteSpace(a?.Text))
         throw new InvalidOperationException("Informe o título do filme.");
     if (!int.TryParse(b?.Text, out int year))
         throw new InvalidOperationException("Informe um ano válido.");
     if (!double.TryParse(c?.Text, System.Globalization.NumberStyles.Any,
             System.Globalization.CultureInfo.CurrentCulture, out double rating) ||
         rating < 0 || rating > 10)
         throw new InvalidOperationException("A nota deve estar entre 0 e 10.");
     if (genreBox?.SelectedItem is not Genre genre ||
         directorBox?.SelectedItem is not Director director)
         throw new InvalidOperationException("Selecione um gênero e um diretor.");
     if (update && selectedMovie is null)
         throw new InvalidOperationException("Selecione um filme para atualizar.");

     var movie = update ? selectedMovie! : new Movie();
     movie.Title = a.Text.Trim();
     movie.ReleaseYear = year;
     movie.Rating = rating;
     movie.GenreId = genre.Id;
     movie.DirectorId = director.Id;
     movie.Genre = null;
     movie.Director = null;
     movie.Synopsis = d?.Text.Trim() ?? "";

     if (update)
         await service.UpdateMovie(movie);
     else
         await service.AddMovie(movie);

     ClearMovie();
     await RefreshMovies();
 }
 async Task DeleteMovie(){if(selectedMovie is null){Error(new InvalidOperationException("Selecione um filme na tabela."));return;}try{await service.DeleteMovie(selectedMovie.Id);ClearMovie();await RefreshMovies();}catch(Exception ex){Error(ex);}}
 void SelectMovie(){if(grid?.SelectedItem is not object[] x)return;var all=db.Movies.Include(m=>m.Genre).Include(m=>m.Director).AsNoTracking().ToList();selectedMovie=all.FirstOrDefault(m=>m.Id==Convert.ToInt32(x[0]));if(selectedMovie is null)return;a!.Text=selectedMovie.Title;b!.Text=selectedMovie.ReleaseYear.ToString();c!.Text=selectedMovie.Rating.ToString("0.0");d!.Text=selectedMovie.Synopsis;genreBox!.SelectedValuePath="Id";genreBox.SelectedValue=selectedMovie.GenreId;directorBox!.SelectedValuePath="Id";directorBox.SelectedValue=selectedMovie.DirectorId;}
 void ClearMovie(){selectedMovie=null;if(grid!=null)grid.SelectedItem=null;if(a!=null)a.Text="";if(b!=null)b.Text="";if(c!=null)c.Text="";if(d!=null)d.Text="";if(genreBox!=null)genreBox.SelectedIndex=-1;if(directorBox!=null)directorBox.SelectedIndex=-1;}
 void ClearFields(){if(grid!=null)grid.SelectedItem=null;if(a!=null)a.Text="";if(b!=null)b.Text="";if(c!=null)c.Text="";}
 static int ParseInt(string? s,int fallback)=>int.TryParse(s,out var n)?n:fallback; static double ParseDouble(string? s,double fallback)=>double.TryParse(s,System.Globalization.NumberStyles.Any,System.Globalization.CultureInfo.CurrentCulture,out var n)?n:fallback;
 void Error(Exception ex)=>MessageBox.Show(ex.Message,"CineHub - atenção",MessageBoxButton.OK,MessageBoxImage.Warning);
 Border Card(UIElement child)=>new(){Child=child,Background=white,CornerRadius=new CornerRadius(14),Padding=new Thickness(20),Margin=new Thickness(0,0,0,14),BorderBrush=new SolidColorBrush(Color.FromRgb(231,233,241)),BorderThickness=new Thickness(1)};
 TextBlock Txt(string text,double size,bool bold,Brush color,Thickness? margin=null)=>new(){Text=text,FontSize=size,FontWeight=bold?FontWeights.Bold:FontWeights.Normal,Foreground=color,Margin=margin??new Thickness(0),TextWrapping=TextWrapping.Wrap};
 TextBox Input(Panel parent,string label,double width){var p=new StackPanel{Margin=new Thickness(0,0,10,10),Width=width};p.Children.Add(Txt(label,11,true,muted,new Thickness(0,0,0,5)));var box=new TextBox{Padding=new Thickness(10,8,10,8),FontSize=13,BorderBrush=new SolidColorBrush(Color.FromRgb(220,223,235)),BorderThickness=new Thickness(1)};p.Children.Add(box);parent.Children.Add(p);return box;}
 ComboBox Combo<T>(Panel parent,string label,IEnumerable<T> source) where T:class{var p=new StackPanel{Margin=new Thickness(0,0,10,10),Width=170};p.Children.Add(Txt(label,11,true,muted,new Thickness(0,0,0,5)));var cb=new ComboBox{ItemsSource=source,DisplayMemberPath="Name",Padding=new Thickness(8),FontSize=13};p.Children.Add(cb);parent.Children.Add(p);return cb;}
 DataGrid GridView(string[] headers){var g=new DataGrid{AutoGenerateColumns=false,IsReadOnly=true,CanUserAddRows=false,SelectionMode=DataGridSelectionMode.Single,HeadersVisibility=DataGridHeadersVisibility.Column,GridLinesVisibility=DataGridGridLinesVisibility.Horizontal,Background=white,BorderBrush=new SolidColorBrush(Color.FromRgb(231,233,241)),RowBackground=white,AlternatingRowBackground=new SolidColorBrush(Color.FromRgb(248,249,252)),Margin=new Thickness(0,4,0,15),MinHeight=240};foreach(var h in headers)g.Columns.Add(new DataGridTextColumn{Header=h,Binding=new System.Windows.Data.Binding($"[{Array.IndexOf(headers,h)}]"),Width=h is "Sinopse" or "Descrição"?new DataGridLength(2,DataGridLengthUnitType.Star):new DataGridLength(1,DataGridLengthUnitType.Star)});return g;}
 void Act(Panel host,string label,Func<Task> action){var btn=new Button{Content=label,Background=accent,Foreground=white,Padding=new Thickness(15,9,15,9),Margin=new Thickness(0,4,8,4),BorderThickness=new Thickness(0),Cursor=System.Windows.Input.Cursors.Hand};btn.Click+=async(_,_)=>{try{await action();}catch(Exception ex){Error(ex);}};host.Children.Add(btn);}
 protected override void OnClosed(EventArgs e){db.Dispose();base.OnClosed(e);}
}

