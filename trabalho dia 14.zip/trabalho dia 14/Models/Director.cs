namespace CineHub.Models;
public class Director { public int Id { get; set; } public string Name { get; set; } = ""; public string Country { get; set; } = ""; public int BirthYear { get; set; } public List<Movie> Movies { get; set; } = []; }
