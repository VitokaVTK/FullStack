namespace CineHub.Models;
public class Movie { public int Id { get; set; } public string Title { get; set; } = ""; public int ReleaseYear { get; set; } public int GenreId { get; set; } public Genre? Genre { get; set; } public int DirectorId { get; set; } public Director? Director { get; set; } public double Rating { get; set; } public string Synopsis { get; set; } = ""; }
