namespace CineHub.Repositories;
public interface IRepository<T> where T:class { Task<List<T>> GetAllAsync(); Task<T?> GetAsync(int id); Task AddAsync(T item); Task UpdateAsync(T item); Task DeleteAsync(int id); }
