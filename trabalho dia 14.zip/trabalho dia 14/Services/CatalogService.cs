using CineHub.Data; using CineHub.Models; using CineHub.Repositories; using Microsoft.EntityFrameworkCore;
namespace CineHub.Services;
public class CatalogService {
 readonly CineDbContext db; readonly IRepository<Movie> movieRepository; readonly IRepository<Genre> genreRepository; readonly IRepository<Director> directorRepository;
 public CatalogService(CineDbContext db){this.db=db;movieRepository=new EfRepository<Movie>(db);genreRepository=new EfRepository<Genre>(db);directorRepository=new EfRepository<Director>(db);}
 public Task<List<Genre>> Genres()=>db.Genres.AsNoTracking().Include(x=>x.Movies).OrderBy(x=>x.Name).ToListAsync(); public Task<List<Director>> Directors()=>db.Directors.AsNoTracking().Include(x=>x.Movies).OrderBy(x=>x.Name).ToListAsync();
 public Task<List<Movie>> Movies()=>db.Movies.AsNoTracking().Include(x=>x.Genre).Include(x=>x.Director).OrderBy(x=>x.Title).ToListAsync();
 // LINQ expressions become SQLite parameters; user input is never concatenated into SQL.
 public Task<List<Movie>> Search(string query)=>db.Movies.AsNoTracking().Include(x=>x.Genre).Include(x=>x.Director).Where(x=>x.Title.Contains(query)||x.Genre!.Name.Contains(query)||x.Director!.Name.Contains(query)).OrderBy(x=>x.Title).ToListAsync();
 public Task<int> MovieCount()=>db.Movies.CountAsync(); public Task<int> GenreCount()=>db.Genres.CountAsync(); public Task<int> DirectorCount()=>db.Directors.CountAsync(); public async Task<double> AverageRating()=>await db.Movies.AverageAsync(x=>(double?)x.Rating)??0;
 public Task AddMovie(Movie x)=>Save(()=>movieRepository.AddAsync(x)); public Task UpdateMovie(Movie x)=>Save(()=>movieRepository.UpdateAsync(x)); public Task DeleteMovie(int id)=>Save(()=>movieRepository.DeleteAsync(id));
 public Task AddGenre(Genre x)=>Save(()=>genreRepository.AddAsync(x)); public Task UpdateGenre(Genre x)=>Save(()=>genreRepository.UpdateAsync(x)); public Task DeleteGenre(int id)=>Save(()=>genreRepository.DeleteAsync(id));
 public Task AddDirector(Director x)=>Save(()=>directorRepository.AddAsync(x)); public Task UpdateDirector(Director x)=>Save(()=>directorRepository.UpdateAsync(x)); public Task DeleteDirector(int id)=>Save(()=>directorRepository.DeleteAsync(id));
 static async Task Save(Func<Task> action){try{await action();}catch(DbUpdateConcurrencyException ex){throw new InvalidOperationException("O registro foi alterado por outra operação. Atualize a lista e tente novamente.",ex);}catch(DbUpdateException ex){throw new InvalidOperationException("Não foi possível salvar. Verifique campos obrigatórios, nomes duplicados e vínculos com filmes.",ex);}}
}
